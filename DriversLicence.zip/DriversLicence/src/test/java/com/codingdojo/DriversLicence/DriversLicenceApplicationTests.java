package com.codingdojo.DriversLicence;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DriversLicenceApplicationTests {

	@Test
	public void contextLoads() {
	}

}
