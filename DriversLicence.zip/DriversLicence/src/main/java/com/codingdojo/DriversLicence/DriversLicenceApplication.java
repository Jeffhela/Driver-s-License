package com.codingdojo.DriversLicence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DriversLicenceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DriversLicenceApplication.class, args);
	}

}
